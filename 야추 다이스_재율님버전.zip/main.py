import random
import sys
from collections import Counter 

# ● ┌ ─ ┐ │ └ ┘ 주사위 구성 텍스트
dice_art = {
    1: ("┌─────────┐",
        "│         │",
        "│    ●    │",
        "│         │",
        "└─────────┘"),
    2: ("┌─────────┐",
        "│  ●      │",
        "│         │",
        "│      ●  │",
        "└─────────┘"),
    3: ("┌─────────┐",
        "│  ●      │",
        "│    ●    │",
        "│      ●  │",
        "└─────────┘"),
    4: ("┌─────────┐",
        "│ ●     ● │",
        "│         │",
        "│ ●     ● │",
        "└─────────┘"),
    5: ("┌─────────┐",
        "│ ●     ● │",
        "│    ●    │",
        "│ ●     ● │",
        "└─────────┘"),
    6: ("┌─────────┐",
        "│ ●     ● │",
        "│ ●     ● │",
        "│ ●     ● │",
        "└─────────┘"),
}

# ----------------- 전역 변수 초기화 (두 컨테이너 사용) -----------------
rollable_dices = [] # 굴릴 주사위 (홀드되지 않은 주사위)
held_dices = []     # 홀드된 주사위 (보존되어야 할 주사위)

dices = []          # 족보 계산용 리스트 (rollable_dices + held_dices 합쳐서 정렬)
reroll_count = 2

# [점수, 입력가능/불가능]
score_categories = [
    "Aces(1)", "Deuces(2)", "Threes(3)", "Fours(4)", "Fives(5)", "Sixs(6)",
    "Choice", "4 of a Kind", "Full House", "S.Straight", "L.Straight", "Yacht"
]
score = [[0, True] for _ in range(12)] 

# ----------------- 헬퍼 함수 -----------------

def print_dice_art_line(dice_values, label=""):
    """주사위 값 리스트를 받아 한 줄에 그림으로 출력합니다."""
    lines = [""] * 5
    
    if not dice_values:
        print(f"** {label} (0개)")
        return
        
    for value in dice_values:
        art = dice_art.get(value)
        if art:
            for i in range(5):
                lines[i] += art[i] + "  " 
    
    print(f"** {label}:")
    print("\n".join(lines))

def print_dice():
    """주사위 텍스트 아트를 출력하고, 홀드된 주사위와 리롤할 주사위를 분리하여 표시합니다."""
    
    global dices
    
    # 1. 주사위 그림은 족보 계산 리스트(dices, 정렬됨)를 기반으로 출력 (요청 반영)
    dice_values_for_art = list(dices)
    
    # 2. 주사위 그림(art)을 행(line)별로 합쳐서 출력
    lines = [""] * 5
    
    if not dice_values_for_art:
        print("현재 굴려진 주사위가 없습니다.")
        return
        
    for value in dice_values_for_art:
        art = dice_art.get(value)
            
        if art:
            for i in range(5):
                lines[i] += art[i] + "  " 
    
    print("\n" + "\n".join(lines) + "\n")
    
    # 3. 주사위 상태 출력 (사용자에게 현재 보유한 주사위를 명확히 표시)
    print("--------------------------------------------------")
    print(f"** Rollable (굴릴 주사위): {sorted(rollable_dices)} ({len(rollable_dices)}개)")
    print(f"** Held (홀드된 주사위): {sorted(held_dices)} ({len(held_dices)}개)")
    
    if dices:
        print(f"** 족보 계산 주사위 값 (Sorted): {dices} **")
    
    print("-" * 50)


def print_dice_for_reroll():
    """리롤 단계에서 사용자가 홀드/해제할 때 그림으로 보여줍니다."""
    
    print("\n" + "="*50)
    print(f"🎲 현재 주사위 상황 (남은 리롤 횟수: {reroll_count}회)")
    print_scoreboard() # 점수판 먼저 출력
    
    print_dice_art_line(sorted(rollable_dices), "Rollable Dices")
    print("\n" + "-"*50 + "\n") # <<< 수정된 부분: Rollable과 Held 사이에 구분선 추가 >>>
    print_dice_art_line(sorted(held_dices), "Held Dices")
    print("="*50)

def dice_refresh(): 
    """두 컨테이너의 값을 합쳐 dices 리스트를 갱신하고 정렬"""
    global dices
    dices.clear()
    
    # rollable_dices와 held_dices의 값을 모두 dices 리스트에 추가
    dices.extend(rollable_dices)
    dices.extend(held_dices)
            
    # 정렬하여 족보 계산에 용이하게 함
    dices.sort()

def dice_roll(): 
    """주사위 1개를 굴립니다."""
    return random.randint(1,6)

def reset_reroll_count():
    """턴 종료 후 리롤 카운트를 2로 초기화"""
    global reroll_count
    reroll_count = 2

def reset_fields():
    """새 턴 시작 시 주사위 리스트를 초기화"""
    global rollable_dices, held_dices
    rollable_dices.clear()
    held_dices.clear()
    dice_refresh() 

# ----------------- 턴 및 롤링 함수 -----------------

def first_roll():
    """턴 첫번째 굴리기: 주사위 5개 굴리고 rollable_dices에 반영"""
    global rollable_dices
    reset_fields()
    
    # 5개 주사위 굴림
    temp_dices = [dice_roll() for _ in range(5)]
    
    # rollable_dices에 할당
    rollable_dices.extend(temp_dices)
        
    dice_refresh()

def reroll():
    """주사위를 홀드/해제하고, rollable_dices의 주사위를 다시 굴립니다."""
    global reroll_count
    global rollable_dices
    global held_dices
    
    if reroll_count == 0:
        print("❌ 리롤 횟수(0회)를 모두 사용했습니다. 점수를 입력해야 합니다.")
        return False
    
    # 현재 주사위 상황 출력 (점수판 포함)
    print_dice_for_reroll() 
    
    # 홀드/홀드 해제 선택
    while True:
        try:
            # 홀드/해제할 주사위 값을 입력받습니다.
            
            choice_str = input("\n[Hold/Unhold] 홀드/해제할 주사위 값(예: 4, 5)을 쉼표(,)로 입력하거나, 'R' 입력 시 리롤 진행: ").upper().strip()
            
            if choice_str == 'R':
                break
            
            selected_values = [int(i.strip()) for i in choice_str.split(',') if i.strip().isdigit()]
            
            if not selected_values:
                 print("유효하지 않은 입력입니다. 주사위 값(1~6)만 입력하거나 'R'을 입력하세요.")
                 continue

            made_action = False
            
            # 주사위 값 기반으로 이동 처리 (동일한 값이 여러 개 있을 경우 하나씩 처리됨)
            for value in selected_values:
                if 1 <= value <= 6:
                    if value in rollable_dices:
                        # Rollable -> Held로 이동 (홀드)
                        rollable_dices.remove(value)
                        held_dices.append(value)
                        print(f"✅ 주사위 ({value})을 홀드했습니다.")
                        made_action = True
                    elif value in held_dices:
                        # Held -> Rollable로 이동 (홀드 해제)
                        held_dices.remove(value)
                        rollable_dices.append(value)
                        print(f"↩️ 주사위 ({value})을 해제했습니다.")
                        made_action = True
                    else:
                        print(f"⚠️ 주사위 값 ({value})는 현재 굴릴/홀드된 목록에 없습니다.")
                else:
                    print(f"❌ 주사위 값은 1부터 6까지여야 합니다. ({value}) 무시.")
            
            if made_action:
                 # 주사위 홀드/해제 후 상태 출력 (사용자 피드백)
                 print("\n현재 주사위 상태:")
                 dice_refresh() # 변경된 상태 반영 후
                 print_dice_for_reroll()
            else:
                 print("수행된 동작이 없습니다. 다시 입력해 주세요.")


        except ValueError:
            print("❌ 잘못된 형식의 입력입니다. 숫자를 쉼표로 구분하여 입력하거나 'R'을 입력하세요.")

    
    # 리롤 실행
    num_to_roll = len(rollable_dices)

    if num_to_roll == 0:
        print("모든 주사위가 홀드 상태입니다. 리롤할 주사위가 없습니다. 횟수 차감 없이 턴 진행.")
        return True
    
    print(f"🔄 총 {num_to_roll}개의 주사위를 다시 굴립니다...")
    
    # Rollable 주사위들을 모두 제거
    rollable_dices.clear() 
    
    # 제거된 수만큼 새 주사위 굴려 rollable_dices에 추가
    for _ in range(num_to_roll):
        rollable_dices.append(dice_roll())

    reroll_count -= 1 
    dice_refresh() # dices 리스트 업데이트 및 정렬

    print(f"✅ 리롤 완료. 남은 횟수: {reroll_count}회")
    return True

# ----------------- 점수 계산식 -----------------
# 모든 함수는 전역 변수 'dices'를 사용합니다.

def Aces(): 
    """1의 개수 * 1"""
    return dices.count(1) * 1
def Deuces(): 
    """2의 개수 * 2"""
    return dices.count(2) * 2
def Threes(): 
    """3의 개수 * 3"""
    return dices.count(3) * 3
def Fours(): 
    """4의 개수 * 4"""
    return dices.count(4) * 4
def Fives(): 
    """5의 개수 * 5"""
    return dices.count(5) * 5
def Sixs(): 
    """6의 개수 * 6"""
    return dices.count(6) * 6
def Choice(): 
    """모든 주사위 합계"""
    return sum(dices)

def Four_of_a_kind():
    if not dices: return 0
    counts = Counter(dices)
    
    # 포카드(4 of a Kind)는 4개 이상의 주사위가 같아야 함
    if any(count >= 4 for count in counts.values()):
        return sum(dices)
    return 0

def FullHouse():
    if not dices: return 0
    counts = Counter(dices)
    
    # Full House는 주사위 종류가 2개이고 개수 구성이 2개와 3개여야 함
    if len(counts) == 2 and sorted(counts.values()) == [2, 3]:
        return sum(dices)
    return 0

def S_Straight():
    if len(dices) < 4: return 0
    dice_set = set(dices)
    patterns = [{1,2,3,4}, {2,3,4,5}, {3,4,5,6}]
    for pattern in patterns:
        if pattern.issubset(dice_set): 
            return 15
    return 0

def L_Straight():
    if len(dices) < 5: return 0
    dice_set = set(dices)
    if {1,2,3,4,5}.issubset(dice_set) or {2,3,4,5,6}.issubset(dice_set):
        return 30
    return 0

def Yacht():
    if not dices: return 0
    if len(set(dices)) == 1:
        return 50
    return 0

# 점수 계산 함수를 인덱스 순서대로 리스트에 매핑
score_funcs = [
    Aces, Deuces, Threes, Fours, Fives, Sixs,
    Choice, Four_of_a_kind, FullHouse, S_Straight, L_Straight, Yacht
]

# ----------------- 점수판 관리 함수 -----------------

def calculate_upper_bonus(current_score):
    """상단 섹션 보너스 (Aces ~ Sixs 합계가 63점 이상일 때 35점) 계산"""
    upper_score_sum = sum(current_score[i][0] for i in range(6))
    return upper_score_sum, 35 if upper_score_sum >= 63 else 0

def print_scoreboard():
    """현재 점수판을 출력하고 가능한 점수를 표시"""
    current_score = score 
    
    # 1. 예상 점수 계산 (사용자가 현재 dices로 얻을 수 있는 점수)
    estimated_scores = [func() for func in score_funcs]
    
    # 2. 점수판 출력
    print("\n" + "="*50)
    print("                << 야추 점수판 >>               ")
    print("="*50)
    
    upper_sum, bonus = calculate_upper_bonus(current_score)
    total_score = upper_sum + bonus + sum(current_score[i][0] for i in range(6, 12))
    
    # 상단 섹션 (Aces ~ Sixs)
    print("--- 상단 섹션 (Upper Section) --------------------")
    for i in range(6):
        # 족보가 입력되지 않았고, 예상 점수가 0보다 클 때만 예상 점수를 표시
        status = "✅" if not current_score[i][1] else (f"(예상: {estimated_scores[i]})" if estimated_scores[i] > 0 else "")
        score_val = current_score[i][0]
        
        # 족보 이름 (왼쪽 정렬, 12자)
        # 점수 (오른쪽 정렬, 5자)
        # 예상/확정 상태 (왼쪽 정렬)
        print(f"[{i+1:2}] {score_categories[i]:<12} | {score_val:5}점 | {status}")

    print("-" * 50)
    print(f"  상단 섹션 합계: {upper_sum}점 | 보너스 (63점 이상 시 35점): {bonus}점")
    print("-" * 50)
    
    # 하단 섹션 (Choice ~ Yacht)
    print("--- 하단 섹션 (Lower Section) --------------------")
    for i in range(6, 12):
        # 족보가 입력되지 않았고, 예상 점수가 0보다 클 때만 예상 점수를 표시
        status = "✅" if not current_score[i][1] else (f"(예상: {estimated_scores[i]})" if estimated_scores[i] > 0 else "")
        score_val = current_score[i][0]
        
        # 인덱스를 7부터 12로 표시
        print(f"[{i+1:2}] {score_categories[i]:<12} | {score_val:5}점 | {status}")
        
    print("="*50)
    print(f"최종 점수: {total_score}점")
    print("="*50)

def score_entry():
    """사용자에게 족보를 선택하도록 하고 점수를 기록합니다."""
    
    # 점수 기록 전 최종 주사위 상태 출력
    print("\n최종 주사위:")
    
    while True:
        print_scoreboard() # 점수판을 먼저 출력
        print_dice()       # 주사위 그림을 나중에 출력
        try:
            choice_idx = input("기록할 족보의 번호(1~12)를 입력하세요: ")
            if not choice_idx.strip():
                continue
                
            choice_idx = int(choice_idx) - 1 # 1-base index를 0-base index로 변환
            
            if 0 <= choice_idx <= 11:
                if score[choice_idx][1]: # 입력 가능(True)일 때
                    
                    # 1. 점수 계산
                    calculated_score = score_funcs[choice_idx]()
                    
                    # 2. 점수 기록
                    score[choice_idx][0] = calculated_score
                    score[choice_idx][1] = False # 입력 불가능 처리
                    
                    # 3. 턴 종료
                    reset_reroll_count()
                    print(f"\n🎉 '{score_categories[choice_idx]}'에 {calculated_score}점을 기록했습니다. 턴이 종료됩니다.")
                    return True # 턴 종료 성공
                else:
                    print("❌ 이미 점수가 기록된 족보입니다. 다른 족보를 선택해 주세요.")
            else:
                print("❌ 족보 번호는 1부터 12까지입니다.")
        
        except ValueError:
            print("❌ 숫자를 입력해 주세요.")
        except IndexError:
            # 이론적으로는 0<=choice_idx<=11 조건에서 발생하지 않지만, 방어 코드
             print("❌ 족보 번호는 1부터 12까지입니다.")


# ----------------- 메인 게임 루프 -----------------

def main_game_loop():
    """야추 게임의 전체 턴을 관리하는 메인 함수"""
    print("=" * 50)
    print("              Py-Yacht Game Start!              ")
    print("================================================")
    
    # 총 12턴 (12개의 족보)
    for turn in range(1, 13): 
        print(f"\n\n==================== [ {turn} / 12 턴 시작 ] ====================")
        
        # 1. 턴 초기화 및 첫 번째 굴리기
        reset_reroll_count()
        first_roll()
        
        # <<< 순서 변경: 점수판 먼저 출력, 주사위 그림 나중에 출력 >>>
        print("\n[ 1st Roll 결과 ]")
        print_scoreboard() 
        print_dice()
        
        # 2. 리롤 단계 (최대 2회)
        # 리롤 횟수 1, 2회 모두 처리 (reroll_count가 1일 때 마지막 리롤이 됨)
        for roll_num in range(1, 3): 
            if reroll_count > 0:
                # 리롤 횟수가 1회 남았을 때 (마지막 리롤 기회)
                is_last_reroll_opportunity = (reroll_count == 1)

                reroll_choice = input(f"\n[ 남은 리롤 횟수: {reroll_count}회 ] 리롤을 진행하시겠습니까? (Y/N): ").upper().strip()
                
                if reroll_choice == 'Y':
                    reroll_success = reroll() 
                    
                    if reroll_success:
                        print(f"\n[ {roll_num+1} Roll 결과 ]")
                        print_scoreboard() # 점수판 먼저 출력
                        print_dice()       # 주사위 그림 나중에 출력
                        
                        # 마지막 리롤 기회였으면 강제 종료 (점수 입력 단계로 이동)
                        if is_last_reroll_opportunity:
                            break 
                    else: 
                         break
                else:
                    break # 리롤을 원하지 않으면 다음 단계(점수 입력)로 넘어감
            else:
                 break # 리롤 횟수 0이면 탈출

        # 3. 점수 입력 단계
        print("\n" + "="*50)
        print("점수를 기록해야 합니다. 현재 주사위로 얻을 수 있는 점수를 확인하세요.")
        score_entry()
        
    # 4. 게임 종료 및 최종 점수 출력
    print("\n\n==================== [ GAME OVER ] ====================")
    print("모든 턴이 종료되었습니다. 최종 점수입니다.")
    print_scoreboard()
    print("=======================================================")


if __name__ == "__main__":
    try:
        main_game_loop()
    except EOFError:
        print("\n\n게임이 강제 종료되었습니다. (EOF 감지)")
        sys.exit(0)