import tkinter as tk
from tkinter import messagebox
import random
from collections import Counter
import sys

# ----------------- 전역 설정 및 상수 -----------------
# 주사위 눈을 유니코드 문자로 대체
DICE_SYMBOLS = {
    1: '⚀', 2: '⚁', 3: '⚂', 4: '⚃', 5: '⚄', 6: '⚅'
}
SCORE_CATEGORIES = [
    "Aces(1)", "Deuces(2)", "Threes(3)", "Fours(4)", "Fives(5)", "Sixs(6)",
    "Choice", "4 of a Kind", "Full House", "S.Straight", "L.Straight", "Yacht"
]
MAX_ROLLS = 3
HELD_COLOR = "lightblue"
UNHELD_COLOR = "SystemButtonFace"

# --- 색상 팔레트 변경 (덜 튀는 색상) ---
UPPER_BG = "#E0FFFF"       # AquaMarine 계열
LOWER_BG = "#FFE4E1"       # MistyRose 계열
SUM_BG = "#D3D3D3"         # LightGray
FINAL_BG = "#336699"       # Dark Blue

class YachtGameGUI:
    def __init__(self, master):
        self.master = master
        master.title("Py-Yacht Game (Tkinter GUI)")
        
        # <<< 캔버스 크기 조정: 늘어난 표 크기에 맞게 창 크기를 키움 >>>
        master.geometry("600x850") # 가로 600, 세로 850
        master.resizable(False, False)

        # ----------------- 게임 상태 변수 -----------------
        self.rollable_dices = [] # Hold 되지 않은 주사위 값
        self.held_dices = []     # Hold 된 주사위 값
        self.dices = []          # 족보 계산용 (rollable + held)
        self.current_roll = 0    # 현재 굴린 횟수
        self.score = [[0, True] for _ in range(12)] 
        self.turn = 1
        
        # Tkinter 동적 변수
        self.status_text = tk.StringVar(value="새 게임을 시작합니다.")
        self.dice_vars = [tk.StringVar(value="Roll") for _ in range(5)]
        
        # ----------------- UI 요소 초기화 -----------------
        
        # 1. 상태 표시 라벨 (Status)
        tk.Label(master, textvariable=self.status_text, font=('Arial', 14, 'bold'), fg='navy').pack(pady=10)
        
        # 2. 주사위 섹션 (Dice Display)
        self.dice_frame = tk.Frame(master)
        self.dice_frame.pack(pady=10)
        self.dice_buttons = []
        for i in range(5):
            btn = tk.Button(self.dice_frame, textvariable=self.dice_vars[i], 
                            # <<< 수정: 유니코드 지원율이 높은 Consolas 폰트로 변경 >>>
                            font=('Consolas', 60, 'bold'), width=2, height=1,
                            relief=tk.RAISED, borderwidth=3,
                            command=lambda i=i: self.toggle_hold(i))
            btn.pack(side=tk.LEFT, padx=5)
            self.dice_buttons.append(btn)
        
        # 3. 컨트롤 섹션 (Controls)
        self.control_frame = tk.Frame(master)
        self.control_frame.pack(pady=10)
        
        self.roll_button = tk.Button(self.control_frame, text="Roll Dice (1/3)", 
                                     font=('Arial', 16, 'bold'), 
                                     bg='lightgreen', activebackground='green',
                                     command=self.handle_roll)
        self.roll_button.pack(side=tk.LEFT, padx=10)

        # 4. 점수판 섹션 (Scoreboard)
        self.score_frame = tk.Frame(master, borderwidth=2, relief=tk.GROOVE)
        self.score_frame.pack(pady=10, padx=10)
        self.init_scoreboard()

        # 5. 게임 시작
        self.start_new_turn()

    # ----------------- 점수판 UI 초기화 (디자인 개선) -----------------
    
    def init_scoreboard(self):
        # <<< 표 글꼴 크기 증가 (표 크기 키움) >>>
        header_font = ('Arial', 12, 'bold')
        content_font = ('Arial', 11)
        score_font = ('Arial', 11, 'bold')
        final_font = ('Arial', 16, 'bold')
        
        cell_style = {'borderwidth': 1, 'relief': 'solid', 'padx': 8, 'pady': 6} # 패딩 증가
        
        # 헤더
        headers = ["#", "Category", "Score", "Estimated", "Action"]
        for j, header in enumerate(headers):
            tk.Label(self.score_frame, text=header, font=header_font, **cell_style).grid(row=0, column=j, sticky='nsew')
        
        self.score_labels = []
        self.estimated_labels = []
        
        # 상단 섹션 (0-5)
        for i in range(6):
            row = i + 1
            self.create_score_row(i, row, UPPER_BG, content_font, score_font)
            
        # 상단 합계
        self.upper_sum_var = tk.StringVar(value="0")
        self.upper_bonus_var = tk.StringVar(value="0")
        
        tk.Label(self.score_frame, text="Upper Sum", font=score_font, bg=SUM_BG, **cell_style).grid(row=7, column=1, sticky='nsew')
        tk.Label(self.score_frame, textvariable=self.upper_sum_var, font=score_font, fg='blue', bg=SUM_BG, **cell_style).grid(row=7, column=2, sticky='nsew')
        tk.Label(self.score_frame, text="Bonus (63+)", font=score_font, bg=SUM_BG, **cell_style).grid(row=8, column=1, sticky='nsew')
        tk.Label(self.score_frame, textvariable=self.upper_bonus_var, font=score_font, fg='green', bg=SUM_BG, **cell_style).grid(row=8, column=2, sticky='nsew')

        # 하단 섹션 (6-11)
        for i in range(6, 12):
            row = i + 3
            self.create_score_row(i, row, LOWER_BG, content_font, score_font)
            
        # 최종 점수
        self.final_score_var = tk.StringVar(value="0")
        tk.Label(self.score_frame, text="Final Total", font=final_font, fg='white', bg=FINAL_BG, **cell_style).grid(row=16, column=1, sticky='nsew')
        tk.Label(self.score_frame, textvariable=self.final_score_var, font=final_font, fg='white', bg=FINAL_BG, **cell_style).grid(row=16, column=2, sticky='nsew')
        
        # Grid 설정으로 셀이 꽉 차도록 함
        for i in range(17):
            self.score_frame.grid_rowconfigure(i, weight=1)
        for j in range(5):
            self.score_frame.grid_columnconfigure(j, weight=1)

    def create_score_row(self, index, grid_row, bg_color, content_font, score_font):
        cell_style = {'borderwidth': 1, 'relief': 'solid', 'padx': 8, 'pady': 6, 'bg': bg_color}
        
        # Index Label
        tk.Label(self.score_frame, text=str(index + 1), font=content_font, **cell_style).grid(row=grid_row, column=0, sticky='nsew')
        
        # Category Label
        tk.Label(self.score_frame, text=SCORE_CATEGORIES[index], anchor='w', font=content_font, **cell_style).grid(row=grid_row, column=1, sticky='nsew')
        
        # Score Label
        score_var = tk.StringVar(value="--")
        label = tk.Label(self.score_frame, textvariable=score_var, font=score_font, **cell_style)
        label.grid(row=grid_row, column=2, sticky='nsew')
        self.score_labels.append(score_var)
        
        # Estimated Score Label
        estimated_var = tk.StringVar(value="")
        label_est = tk.Label(self.score_frame, textvariable=estimated_var, fg='gray', font=content_font, **cell_style)
        label_est.grid(row=grid_row, column=3, sticky='nsew')
        self.estimated_labels.append(estimated_var)
        
        # Action Button
        btn = tk.Button(self.score_frame, text="Record", font=content_font, command=lambda i=index: self.select_score(i))
        btn.grid(row=grid_row, column=4, sticky='nsew')
        
    # ----------------- 주사위 및 홀드 로직 -----------------
    
    def toggle_hold(self, index):
        if self.current_roll == 0:
            return # 굴리기 전에는 홀드 불가
            
        if self.current_roll == MAX_ROLLS and self.current_roll != 0:
            # 마지막 굴림 후에는 홀드 변경 불가 (점수 기록만 가능)
            return 

        # 주사위 버튼이 표시하는 값 (유니코드 심볼)을 가져옴
        die_symbol = self.dice_vars[index].get()
        die_value = next((k for k, v in DICE_SYMBOLS.items() if v == die_symbol), None)

        if die_value is None:
            return 
        
        # 현재 주사위 값
        selected_value = die_value 
        
        # 현재 홀드된 주사위의 카운트를 임시로 세어봄
        held_count = Counter(self.held_dices)

        # 현재 이 주사위가 held_dices에 포함되는지 여부 판단
        is_held = self.dice_buttons[index]['bg'] == HELD_COLOR
        
        
        # --- 홀드 로직 재확인 및 실행 ---
        
        if is_held:
            # Held -> Rollable (홀드 해제)
            # 중복된 값이 있을 경우, 현재 버튼이 'HELD_COLOR'이고 해당 값이 held_dices에 남아있는지 확인
            if held_count[selected_value] > 0:
                # held에서 rollable로 이동
                self.held_dices.remove(selected_value)
                self.rollable_dices.append(selected_value)
            
        else:
            # Rollable -> Held (홀드)
            # 중복된 값이 있을 경우, 현재 버튼이 'UNHELD_COLOR'이고 해당 값이 rollable_dices에 남아있는지 확인
            if selected_value in self.rollable_dices:
                # rollable에서 held로 이동
                self.rollable_dices.remove(selected_value)
                self.held_dices.append(selected_value)
            
        # 홀드 상태 변경 후 주사위 표시 업데이트
        self.dice_refresh()
        self.update_dice_display() # <--- update_dice_display를 호출하여 색상을 다시 설정하도록 함
        self.update_scoreboard_estimated()

    def update_dice_display(self):
        # 정렬된 전체 주사위 값 (self.dices)을 기반으로 UI를 표시합니다.
        current_dices = self.dices[:]
        
        # Held 상태 확인을 위한 임시 카운터 (중복된 주사위 색상 처리를 위해 사용)
        temp_held_dices = self.held_dices[:]
        
        # 버튼의 텍스트와 색상 업데이트
        for i in range(5):
            if i < len(current_dices):
                value = current_dices[i]
                
                # 주사위 그림(유니코드 심볼) 설정
                self.dice_vars[i].set(DICE_SYMBOLS.get(value, '?')) 
                
                # 홀드 상태 결정
                # 현재 주사위 값(value)이 held_dices에 포함되고, 아직 임시 리스트에서 제거되지 않았다면 홀드 상태
                if value in temp_held_dices:
                    self.dice_buttons[i]['bg'] = HELD_COLOR
                    # 중복 주사위 처리를 위해 임시 리스트에서 해당 값을 제거
                    temp_held_dices.remove(value)
                else:
                    self.dice_buttons[i]['bg'] = UNHELD_COLOR
                    
                # 마지막 롤 후에는 홀드 색상만 풀고 버튼은 비활성화
                if self.current_roll == MAX_ROLLS:
                    self.dice_buttons[i]['bg'] = UNHELD_COLOR 
                    self.dice_buttons[i]['state'] = tk.DISABLED
                else:
                    self.dice_buttons[i]['state'] = tk.NORMAL
            else:
                # 주사위가 5개 미만일 때 빈 버튼 처리
                self.dice_vars[i].set("") # <<< 수정: 빈 문자열로 설정하여 주사위가 안 보이는 문제 해결 >>>
                self.dice_buttons[i]['bg'] = UNHELD_COLOR
                self.dice_buttons[i]['state'] = tk.DISABLED
        
        # 롤링 후 족보 계산 리스트 갱신 (dice_refresh는 이미 handle_roll에서 호출됨)
        # self.dice_refresh() # toggle_hold에서는 호출되므로 여기서는 생략 가능

    # ----------------- 게임 흐름 로직 -----------------
    
    def start_new_turn(self):
        if self.turn > 12:
            self.game_over()
            return
            
        self.current_roll = 0
        self.rollable_dices = []
        self.held_dices = []
        self.dices = []
        
        self.status_text.set(f"턴 {self.turn}/12: 주사위를 굴리세요!")
        self.roll_button.config(text=f"Roll Dice (1/{MAX_ROLLS})", state=tk.NORMAL)
        
        # 주사위 표시 초기화
        for i in range(5):
            self.dice_vars[i].set("") # <<< 수정: 빈 문자열로 초기화 >>>
            self.dice_buttons[i]['bg'] = UNHELD_COLOR
            self.dice_buttons[i]['state'] = tk.NORMAL # 새 턴 시작 시 버튼 활성화
            
        self.update_scoreboard_estimated()
        self.update_scoreboard_score()

    def handle_roll(self):
        if self.current_roll >= MAX_ROLLS:
            messagebox.showinfo("안내", "굴릴 수 있는 횟수를 모두 사용했습니다. 점수를 기록하세요.")
            return

        self.current_roll += 1
        
        # Hold되지 않은 주사위만 굴리기
        num_to_roll = 5 - len(self.held_dices)
        new_rolls = [random.randint(1, 6) for _ in range(num_to_roll)]
        self.rollable_dices = new_rolls
        
        # 디스플레이 업데이트
        self.dice_refresh() # 롤 후 전체 주사위 리스트 갱신 및 정렬
        self.update_dice_display()
        
        # 예상 점수 업데이트
        self.update_scoreboard_estimated()
        
        # 상태 업데이트
        rolls_left = MAX_ROLLS - self.current_roll
        self.status_text.set(f"턴 {self.turn}/12: {self.current_roll}회 굴림. 홀드하고 다시 굴리세요!")
        
        if rolls_left == 0:
            self.roll_button.config(text="Max Rolls!", state=tk.DISABLED)
            self.status_text.set(f"턴 {self.turn}/12: 점수를 기록해야 합니다.")
            # 마지막 롤 후에는 update_dice_display에서 모든 주사위 버튼 색상 해제 및 비활성화 처리됨
        else:
            self.roll_button.config(text=f"Roll Dice ({self.current_roll+1}/{MAX_ROLLS})")

    # ----------------- 점수 계산 로직 (기존 콘솔 로직 재사용) -----------------

    def dice_refresh(self): 
        """rollable_dices와 held_dices를 합쳐 dices 리스트를 갱신하고 정렬"""
        self.dices.clear()
        self.dices.extend(self.rollable_dices)
        self.dices.extend(self.held_dices)
        self.dices.sort()

    def Aces(self): return self.dices.count(1) * 1
    def Deuces(self): return self.dices.count(2) * 2
    def Threes(self): return self.dices.count(3) * 3
    def Fours(self): return self.dices.count(4) * 4
    def Fives(self): return self.dices.count(5) * 5
    def Sixs(self): return self.dices.count(6) * 6
    def Choice(self): return sum(self.dices)

    def Four_of_a_kind(self):
        if len(self.dices) < 4: return 0
        counts = Counter(self.dices)
        if any(count >= 4 for count in counts.values()):
            return sum(self.dices)
        return 0

    def FullHouse(self):
        if len(self.dices) < 5: return 0
        counts = Counter(self.dices)
        if len(counts) == 2 and sorted(counts.values()) == [2, 3]:
            return sum(self.dices)
        return 0

    def S_Straight(self):
        if len(self.dices) < 4: return 0
        dice_set = set(self.dices)
        patterns = [{1,2,3,4}, {2,3,4,5}, {3,4,5,6}]
        for pattern in patterns:
            if pattern.issubset(dice_set): 
                return 15
        return 0

    def L_Straight(self):
        if len(self.dices) < 5: return 0
        dice_set = set(self.dices)
        if {1,2,3,4,5}.issubset(dice_set) or {2,3,4,5,6}.issubset(dice_set):
            return 30
        return 0

    def Yacht(self):
        if not self.dices: return 0
        if len(set(self.dices)) == 1:
            return 50
        return 0

    def get_score_funcs(self):
        return [
            self.Aces, self.Deuces, self.Threes, self.Fours, self.Fives, self.Sixs,
            self.Choice, self.Four_of_a_kind, self.FullHouse, self.S_Straight, self.L_Straight, self.Yacht
        ]

    # ----------------- 점수 기록 및 UI 업데이트 -----------------

    def select_score(self, index):
        if self.current_roll == 0:
            messagebox.showinfo("안내", "주사위를 먼저 굴려야 합니다.")
            return

        if not self.score[index][1]:
            messagebox.showinfo("안내", "이미 기록된 족보입니다.")
            return
            
        score_func = self.get_score_funcs()[index]
        calculated_score = score_func()
        
        self.score[index][0] = calculated_score
        self.score[index][1] = False
        
        self.update_scoreboard_score()
        self.turn += 1
        self.start_new_turn()
        
    def calculate_upper_bonus(self):
        upper_score_sum = sum(self.score[i][0] for i in range(6))
        return upper_score_sum, 35 if upper_score_sum >= 63 else 0

    def update_scoreboard_estimated(self):
        if self.current_roll == 0:
            for est_var in self.estimated_labels:
                est_var.set("")
            return

        score_funcs = self.get_score_funcs()
        for i in range(12):
            if self.score[i][1]: # Only update if available
                estimated = score_funcs[i]()
                self.estimated_labels[i].set(f"({estimated})")
            else:
                 self.estimated_labels[i].set("✅")

    def update_scoreboard_score(self):
        upper_sum, bonus = self.calculate_upper_bonus()
        total_score = upper_sum + bonus + sum(self.score[i][0] for i in range(6, 12))
        
        # Update category scores
        for i in range(12):
            if not self.score[i][1]:
                self.score_labels[i].set(str(self.score[i][0]))
            else:
                 self.score_labels[i].set("--")
        
        # Update totals
        self.upper_sum_var.set(str(upper_sum))
        self.upper_bonus_var.set(str(bonus))
        self.final_score_var.set(str(total_score))

    def game_over(self):
        self.roll_button.config(state=tk.DISABLED)
        messagebox.showinfo("Game Over", f"게임 종료! 최종 점수: {self.final_score_var.get()}점")
        self.status_text.set("게임이 종료되었습니다.")


if __name__ == '__main__':
    root = tk.Tk()
    game = YachtGameGUI(root)
    root.mainloop()