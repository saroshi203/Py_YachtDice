# 수정된 Py-Yacht (인덱스 기반 hold 처리) — 전체 실행 가능 스크립트
import tkinter as tk
from tkinter import messagebox
import random
from collections import Counter

DICE_SYMBOLS = {1: '⚀', 2: '⚁', 3: '⚂', 4: '⚃', 5: '⚄', 6: '⚅'}
SCORE_CATEGORIES = [
    "Aces(1)", "Deuces(2)", "Threes(3)", "Fours(4)", "Fives(5)", "Sixs(6)",
    "Choice", "4 of a Kind", "Full House", "S.Straight", "L.Straight", "Yacht"
]
MAX_ROLLS = 3
HELD_COLOR = "lightblue"
UNHELD_COLOR = "SystemButtonFace"
UPPER_BG = "#E0FFFF"
LOWER_BG = "#FFE4E1"
SUM_BG = "#D3D3D3"
FINAL_BG = "#336699"

class YachtGameGUI:
    def __init__(self, master):
        self.master = master
        master.title("Py-Yacht Game (Tkinter GUI)")
        master.geometry("600x850")
        master.resizable(False, False)

        # 상태
        self.dice_values = [0]*5        # 각 인덱스의 주사위 값 (1~6, 0=빈)
        self.held_flags = [False]*5     # 각 인덱스가 hold됐는지
        self.current_roll = 0
        self.score = [[0, True] for _ in range(12)]
        self.turn = 1

        # UI 변수
        self.status_text = tk.StringVar(value="새 게임을 시작합니다.")
        self.dice_vars = [tk.StringVar(value="") for _ in range(5)]

        tk.Label(master, textvariable=self.status_text, font=('Arial', 14, 'bold'), fg='navy').pack(pady=10)

        self.dice_frame = tk.Frame(master)
        self.dice_frame.pack(pady=10)
        self.dice_buttons = []
        for i in range(5):
            btn = tk.Button(self.dice_frame, textvariable=self.dice_vars[i],
                            font=('Consolas', 60, 'bold'), width=2, height=1,
                            relief=tk.RAISED, borderwidth=3,
                            command=lambda i=i: self.toggle_hold(i))
            btn.pack(side=tk.LEFT, padx=5)
            self.dice_buttons.append(btn)

        self.control_frame = tk.Frame(master)
        self.control_frame.pack(pady=10)

        self.roll_button = tk.Button(self.control_frame, text="Roll Dice (1/3)",
                                     font=('Arial', 16, 'bold'),
                                     bg='lightgreen', activebackground='green',
                                     command=self.handle_roll)
        self.roll_button.pack(side=tk.LEFT, padx=10)

        self.score_frame = tk.Frame(master, borderwidth=2, relief=tk.GROOVE)
        self.score_frame.pack(pady=10, padx=10)
        self.init_scoreboard()

        self.start_new_turn()

    def init_scoreboard(self):
        header_font = ('Arial', 12, 'bold')
        content_font = ('Arial', 11)
        score_font = ('Arial', 11, 'bold')
        final_font = ('Arial', 16, 'bold')
        cell_style = {'borderwidth': 1, 'relief': 'solid', 'padx': 8, 'pady': 6}

        headers = ["#", "Category", "Score", "Estimated", "Action"]
        for j, header in enumerate(headers):
            tk.Label(self.score_frame, text=header, font=header_font, **cell_style).grid(row=0, column=j, sticky='nsew')

        self.score_labels = []
        self.estimated_labels = []

        for i in range(6):
            row = i + 1
            self.create_score_row(i, row, UPPER_BG, content_font, score_font)

        self.upper_sum_var = tk.StringVar(value="0")
        self.upper_bonus_var = tk.StringVar(value="0")
        tk.Label(self.score_frame, text="Upper Sum", font=score_font, bg=SUM_BG, **cell_style).grid(row=7, column=1, sticky='nsew')
        tk.Label(self.score_frame, textvariable=self.upper_sum_var, font=score_font, fg='blue', bg=SUM_BG, **cell_style).grid(row=7, column=2, sticky='nsew')
        tk.Label(self.score_frame, text="Bonus (63+)", font=score_font, bg=SUM_BG, **cell_style).grid(row=8, column=1, sticky='nsew')
        tk.Label(self.score_frame, textvariable=self.upper_bonus_var, font=score_font, fg='green', bg=SUM_BG, **cell_style).grid(row=8, column=2, sticky='nsew')

        for i in range(6, 12):
            row = i + 3
            self.create_score_row(i, row, LOWER_BG, content_font, score_font)

        self.final_score_var = tk.StringVar(value="0")
        tk.Label(self.score_frame, text="Final Total", font=final_font, fg='white', bg=FINAL_BG, **cell_style).grid(row=16, column=1, sticky='nsew')
        tk.Label(self.score_frame, textvariable=self.final_score_var, font=final_font, fg='white', bg=FINAL_BG, **cell_style).grid(row=16, column=2, sticky='nsew')

        for i in range(17):
            self.score_frame.grid_rowconfigure(i, weight=1)
        for j in range(5):
            self.score_frame.grid_columnconfigure(j, weight=1)

    def create_score_row(self, index, grid_row, bg_color, content_font, score_font):
        cell_style = {'borderwidth': 1, 'relief': 'solid', 'padx': 8, 'pady': 6, 'bg': bg_color}
        tk.Label(self.score_frame, text=str(index + 1), font=content_font, **cell_style).grid(row=grid_row, column=0, sticky='nsew')
        tk.Label(self.score_frame, text=SCORE_CATEGORIES[index], anchor='w', font=content_font, **cell_style).grid(row=grid_row, column=1, sticky='nsew')
        score_var = tk.StringVar(value="--")
        label = tk.Label(self.score_frame, textvariable=score_var, font=score_font, **cell_style)
        label.grid(row=grid_row, column=2, sticky='nsew')
        self.score_labels.append(score_var)
        estimated_var = tk.StringVar(value="")
        label_est = tk.Label(self.score_frame, textvariable=estimated_var, fg='gray', font=content_font, **cell_style)
        label_est.grid(row=grid_row, column=3, sticky='nsew')
        self.estimated_labels.append(estimated_var)
        btn = tk.Button(self.score_frame, text="Record", font=content_font, command=lambda i=index: self.select_score(i))
        btn.grid(row=grid_row, column=4, sticky='nsew')

    # 인덱스 기반 토글
    def toggle_hold(self, index):
        if self.current_roll == 0:
            return
        if self.current_roll >= MAX_ROLLS:
            return
        # 토글
        self.held_flags[index] = not self.held_flags[index]
        self.update_dice_display()
        self.update_scoreboard_estimated()

    def update_dice_display(self):
        for i in range(5):
            val = self.dice_values[i]
            if val:
                self.dice_vars[i].set(DICE_SYMBOLS.get(val, '?'))
            else:
                self.dice_vars[i].set("")
            # 색상/상태
            if self.current_roll == 0:
                # 새턴: 모두 활성화(굴리기 전엔 홀드 불가하지만 버튼은 켜둠)
                self.dice_buttons[i]['state'] = tk.NORMAL
                self.dice_buttons[i]['bg'] = UNHELD_COLOR
            else:
                # 굴린 상태: held 표시
                self.dice_buttons[i]['state'] = tk.NORMAL
                self.dice_buttons[i]['bg'] = HELD_COLOR if self.held_flags[i] else UNHELD_COLOR
                if self.current_roll >= MAX_ROLLS:
                    # 마지막 롤 후에는 버튼 비활성화
                    self.dice_buttons[i]['state'] = tk.DISABLED
                    # 원하면 표시 색상은 유지(여기선 해제하려면 UNHELD_COLOR로 바꾸려면 아래를 조정)
        # Roll 버튼 상태도 관리(이미 handle_roll에서 변경됨)

    def start_new_turn(self):
        if self.turn > 12:
            self.game_over()
            return
        self.current_roll = 0
        self.dice_values = [0]*5
        self.held_flags = [False]*5
        self.status_text.set(f"턴 {self.turn}/12: 주사위를 굴리세요!")
        self.roll_button.config(text=f"Roll Dice (1/{MAX_ROLLS})", state=tk.NORMAL)
        for i in range(5):
            self.dice_vars[i].set("")
            self.dice_buttons[i]['bg'] = UNHELD_COLOR
            self.dice_buttons[i]['state'] = tk.NORMAL
        self.update_scoreboard_estimated()
        self.update_scoreboard_score()

    def handle_roll(self):
        if self.current_roll >= MAX_ROLLS:
            messagebox.showinfo("안내", "굴릴 수 있는 횟수를 모두 사용했습니다. 점수를 기록하세요.")
            return
        if not messagebox.askyesno("확인", "주사위를 굴릴까요?"):
            return

        self.current_roll += 1
        # held_flags False인 인덱스만 굴림
        for i in range(5):
            if not self.held_flags[i]:
                self.dice_values[i] = random.randint(1,6)
        self.update_dice_display()
        self.update_scoreboard_estimated()
        rolls_left = MAX_ROLLS - self.current_roll
        self.status_text.set(f"턴 {self.turn}/12: {self.current_roll}회 굴림. 홀드하고 다시 굴리세요!")
        if rolls_left == 0:
            self.roll_button.config(text="Max Rolls!", state=tk.DISABLED)
            self.status_text.set(f"턴 {self.turn}/12: 점수를 기록해야 합니다.")
            # 마지막 롤 후 버튼 비활성화는 update_dice_display에서 처리
        else:
            self.roll_button.config(text=f"Roll Dice ({self.current_roll+1}/{MAX_ROLLS})")

    # 점수 계산 (dices는 현재 dice_values에서 0 제거하고 정렬)
    def dice_list(self):
        return sorted([v for v in self.dice_values if v])

    def Aces(self): return self.dice_list().count(1) * 1
    def Deuces(self): return self.dice_list().count(2) * 2
    def Threes(self): return self.dice_list().count(3) * 3
    def Fours(self): return self.dice_list().count(4) * 4
    def Fives(self): return self.dice_list().count(5) * 5
    def Sixs(self): return self.dice_list().count(6) * 6
    def Choice(self): return sum(self.dice_list())

    def Four_of_a_kind(self):
        d = self.dice_list()
        if len(d) < 4: return 0
        counts = Counter(d)
        if any(count >= 4 for count in counts.values()): return sum(d)
        return 0

    def FullHouse(self):
        d = self.dice_list()
        if len(d) < 5: return 0
        counts = Counter(d)
        if len(counts) == 2 and sorted(counts.values()) == [2,3]: return sum(d)
        return 0

    def S_Straight(self):
        d = set(self.dice_list())
        patterns = [{1,2,3,4}, {2,3,4,5}, {3,4,5,6}]
        for p in patterns:
            if p.issubset(d): return 15
        return 0

    def L_Straight(self):
        d = set(self.dice_list())
        if {1,2,3,4,5}.issubset(d) or {2,3,4,5,6}.issubset(d): return 30
        return 0

    def Yacht(self):
        d = self.dice_list()
        if not d: return 0
        if len(set(d)) == 1 and len(d) == 5: return 50
        return 0

    def get_score_funcs(self):
        return [
            self.Aces, self.Deuces, self.Threes, self.Fours, self.Fives, self.Sixs,
            self.Choice, self.Four_of_a_kind, self.FullHouse, self.S_Straight, self.L_Straight, self.Yacht
        ]

    def select_score(self, index):
        if not messagebox.askyesno("확인", f"{SCORE_CATEGORIES[index]}에 점수를 기록할까요?"):
            return
        if self.current_roll == 0:
            messagebox.showinfo("안내", "주사위를 먼저 굴려야 합니다.")
            return
        if not self.score[index][1]:
            messagebox.showinfo("안내", "이미 기록된 족보입니다.")
            return
        score_func = self.get_score_funcs()[index]
        calculated_score = score_func()
        self.score[index][0] = calculated_score
        self.score[index][1] = False
        self.update_scoreboard_score()
        self.turn += 1
        self.start_new_turn()

    def calculate_upper_bonus(self):
        upper_score_sum = sum(self.score[i][0] for i in range(6))
        return upper_score_sum, 35 if upper_score_sum >= 63 else 0

    def update_scoreboard_estimated(self):
        if self.current_roll == 0:
            for est_var in self.estimated_labels:
                est_var.set("")
            return
        score_funcs = self.get_score_funcs()
        for i in range(12):
            if self.score[i][1]:
                estimated = score_funcs[i]()
                self.estimated_labels[i].set(f"({estimated})")
            else:
                self.estimated_labels[i].set("✅")

    def update_scoreboard_score(self):
        upper_sum, bonus = self.calculate_upper_bonus()
        total_score = upper_sum + bonus + sum(self.score[i][0] for i in range(6, 12))
        for i in range(12):
            if not self.score[i][1]:
                self.score_labels[i].set(str(self.score[i][0]))
            else:
                self.score_labels[i].set("--")
        self.upper_sum_var.set(str(upper_sum))
        self.upper_bonus_var.set(str(bonus))
        self.final_score_var.set(str(total_score))

    def game_over(self):
        self.roll_button.config(state=tk.DISABLED)
        messagebox.showinfo("Game Over", f"게임 종료! 최종 점수: {self.final_score_var.get()}점")
        self.status_text.set("게임이 종료되었습니다.")

if __name__ == '__main__':
    root = tk.Tk()
    game = YachtGameGUI(root)
    root.mainloop()
